# planner-v2.2.1 -- final delivery (EACCES fix + independent-guard.test.mjs merged)

Branch: dev/claude-planner-v2. Not merged to main. AI/Cloudflare/Gemini/AZIZ/SARA/SHARA/UI untouched.
Planner logic (src/planner.mjs runtime behaviour) and every test assertion -- existing and
independent-guard.test.mjs -- are unchanged in this batch. Only tools/mutants.mjs (the EACCES
fix) and the addition of independent-guard.test.mjs are new. See "Files changed" at the bottom.

Parent ZIP: claude-planner-v2.2.1-WIP.zip, sha256 b3bdb4ec48e7b20776c92d02ce72501d3d3ce23ddda4cca6d1ee43da47778256
(the subject named in CLAUDE-NEXT-PATCH.md).

## Status summary

- Runtime tests: **VERIFIED** -- 62/62 (52 existing + 10 independent-guard.test.mjs), fresh ZIP extraction, src mode 0444.
- Independent guard: **VERIFIED** -- independent-guard.test.mjs, only its 2 imports adjusted, all 10 pass; 9 of the 10 independently caught a distinct planted fault in the mutation run below.
- Mutation suite: **20/20 VERIFIED** on fresh ZIP extraction with src mode 0444.
- Source typecheck/build: verified in Claude's environment; independent reinstall via a fresh `npm ci` is deferred for lack of a lockfile.
- Dependency lock: **PENDING** -- not a claim of success. See "Open item" below.

## What "fresh ZIP extraction" means here

Not a simulation. Sequence actually run for this delivery:
1. Source tree assembled (fix + independent-guard.test.mjs merged in).
2. `zip -r` of that tree, no manual chmod -- a real ZIP, this exact deliverable.
3. That ZIP unpacked into a brand-new empty directory.
4. `ls -l src/*.mjs` at that point showed `estimates.mjs` and `planner.mjs` at mode 0444
   (zip preserved the working tree's own file modes) -- the same condition Az's reviewer hit on
   the delivered v2.2.1-WIP.zip. No chmod was applied before running anything below.
5. Every command below ran from that directory, in one continuous session, no retries.

## Results (Node v22.22.2, TypeScript 6.0.3)

| Step | Command | Exit |
|---|---|---|
| Typecheck (`strict: true`, src/ only) | npm run planner:typecheck | 0 |
| Tests 62/62 | node --test tests/*.test.mjs | 0 |
| Build | node build.mjs | 0 |
| Isolated mutation, 20/20 killed, single run, no retries | node tools/mutants.mjs | 0 |

Full command transcripts: evidence/typecheck.log, evidence/tests.log, evidence/build.log,
evidence/mutants.log (the last also carries the src/ sha256 before and after, reproduced below).

## Item 1 -- tools/mutants.mjs EACCES fix

Before writing a mutant into its temp sandbox copy, the tool now chmods every file it just copied
to 0o644:
```js
cpSync(SRC, join(sandbox, 'src'), { recursive: true });
for (const f of readdirSync(join(sandbox, 'src'))) chmodSync(join(sandbox, 'src', f), 0o644);
```
Only the sandbox copy is touched; the package's own src/ is never opened for writing by this tool.
Confirmed above: sha256 of src/*.mjs is identical before and after a full 20-mutant run, on a
tree whose src/ was 0444 throughout (not writable by this fix -- by design; the fix targets the
tool's own temp copy).

## Item 3 -- independent-guard.test.mjs

Diff against the file as supplied: only the two import paths changed, nothing else:
```diff
- import { generateModel, validateModel, defaultRooms, footprintDiagnostics, quantities } from '../work/claude-planner-v2/src/planner.mjs';
- import { importModel } from '../work/claude-planner-v2/src/migrations.mjs';
+ import { generateModel, validateModel, defaultRooms, footprintDiagnostics, quantities } from '../src/planner.mjs';
+ import { importModel } from '../src/migrations.mjs';
```
Every test body and assertion is byte-identical to the supplied file. All 10 (IG01-IG10) pass.
In the mutation run above, IG01/IG02/IG03/IG04/IG05/IG06/IG08/IG09/IG10 each independently caught
a distinct planted fault -- evidence that this file exercises real, separate code paths rather
than duplicating the existing suite.

## Open item -- package-lock.json / npm ci

Not delivered, as agreed. This environment has no outbound network access; requests to the npm
registry return `403 Forbidden` here, and no cached copy of typescript's real registry
`integrity`/`resolved` metadata exists locally to build a lock file from truthfully. A
hand-written lock file with fabricated integrity hashes would fail `npm ci` outright, or worse,
silently pass a check it shouldn't -- so none was produced.

Agreed path: Az generates `package-lock.json` via `npm install` in an environment with registry
access and sends it back; Claude then verifies `npm ci` -> the four `planner:*` scripts from a
fresh unpack with that real lock file, and delivers a follow-up ZIP. Until that lock file exists,
`npm ci` cannot be exercised from this package, and this delivery does not claim otherwise.

## Test-file typecheck gate

Same disclosed state as v2.2.1-WIP: tests/*.test.mjs (now 5 files, including
independent-guard.test.mjs) were previously confirmed to type-check cleanly under `tsc --strict`
when @types/node is present, using a locally-available @types/node copy in an earlier message --
that is not re-verified in this delivery. `npm run planner:typecheck` in this package checks
src/*.mjs only; @types/node is not yet a devDependency (would be added together with the lock
file). The "Typecheck: 0" result above covers src/ only, not tests/.

## Files changed vs v2.2.1-WIP

| File | Change |
|---|---|
| tools/mutants.mjs | EACCES fix: chmod the sandbox copy before mutating it |
| tests/independent-guard.test.mjs | new; only its 2 import paths adjusted |
| GATE-MANIFEST.md | this file |
| evidence/*.log, evidence/src-hashes.txt | this delivery's own run output |

Everything else -- src/planner.mjs, src/PlannerOutputContract.mjs, src/migrations.mjs,
src/estimates.mjs, build.mjs, tsconfig.json, docs/, tools/ast-equal.mjs, and the other 4 test
files (hardening.test.mjs, regression.test.mjs, shapes.test.mjs, shape-geometry.test.mjs) -- is
byte-identical to v2.2.1-WIP. No Planner runtime logic and no existing test assertion changed in
this batch.

## src/ hashes -- before and after the mutation run (this delivery)

```
e36c24dd6351802bf7b4d18300ce81e46439b0f6bb9cc845794864a8662775a4  src/PlannerOutputContract.mjs
59ea7f70e877160024944e9f54665db3f49866d27bdbb6d390f80d0576eb19cf  src/estimates.mjs
b22b9545ccaade59a825424cf546b5c4e6d62c84ed0eefd7bd1622b0e1c40fb9  src/migrations.mjs
8cf6b34251a9920b3da1912951b5ba2f425ae5b4f5f8946b12dfddafa0692560  src/planner.mjs
```
Identical before and after. Full hash list for every source/tooling/doc/test file:
evidence/src-hashes.txt.
