import type {
  EngineAdapter, EngineInputContract, EngineOutputContract, EngineExecutionContext,
} from './types.js';
import { fnv1aHash, stableStringify, NonJsonInputError } from './util.js';
import { validateEngineOutput } from './output-validation.js';

export interface InvocationResult {
  engineId: string;
  engineVersion: string;
  ok: boolean;
  output?: EngineOutputContract;
  error?: string;
}

async function bounded<T>(
  work: (signal: AbortSignal) => Promise<T>,
  timeoutMs: number,
): Promise<T> {
  if (!Number.isFinite(timeoutMs) || timeoutMs <= 0) throw new Error('INVALID_TIMEOUT');
  const controller = new AbortController();
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([
      work(controller.signal),
      new Promise<never>((_, reject) => {
        timer = setTimeout(() => {
          controller.abort();
          reject(new Error('ENGINE_TIMEOUT'));
        }, timeoutMs);
      }),
    ]);
  } finally {
    if (timer !== undefined) clearTimeout(timer);
  }
}

export class AdapterRegistry {
  private adapters = new Map<string, EngineAdapter>();

  register(adapter: EngineAdapter): void {
    if (!adapter.engineId.trim()) throw new Error('Adapter engineId is required');
    if (this.adapters.has(adapter.engineId)) throw new Error(`Adapter ${adapter.engineId} already registered`);
    this.adapters.set(adapter.engineId, adapter);
  }

  unregister(engineId: string): boolean { return this.adapters.delete(engineId); }
  get(engineId: string): EngineAdapter | undefined { return this.adapters.get(engineId); }
  all(): EngineAdapter[] { return [...this.adapters.values()]; }
  size(): number { return this.adapters.size; }

  async invokeAll(input: EngineInputContract, timeoutMs = 30000): Promise<InvocationResult[]> {
    return Promise.all(this.all().map((a) => this.invokeOne(a, input, timeoutMs)));
  }

  private async invokeOne(
    adapter: EngineAdapter,
    input: EngineInputContract,
    timeoutMs: number,
  ): Promise<InvocationResult> {
    let inputHash: string;
    try {
      inputHash = fnv1aHash(stableStringify(input));
    } catch (e) {
      return {
        engineId: adapter.engineId,
        engineVersion: adapter.engineVersion,
        ok: false,
        error: e instanceof NonJsonInputError ? `INVALID_ENGINE_INPUT: ${e.message}` : 'INVALID_ENGINE_INPUT',
      };
    }
    try {
      if (adapter.healthCheck) {
        const h = await bounded(() => adapter.healthCheck!(), timeoutMs);
        if (!h?.healthy) {
          return {
            engineId: adapter.engineId,
            engineVersion: adapter.engineVersion,
            ok: false,
            error: `unhealthy: ${h?.reason ?? 'unknown'}`,
          };
        }
      }
      const output = await bounded(
        (signal) => adapter.execute(input, { signal, deadlineMs: timeoutMs } satisfies EngineExecutionContext),
        timeoutMs,
      );
      const check = validateEngineOutput(output, adapter, inputHash);
      if (!check.ok) {
        return {
          engineId: adapter.engineId,
          engineVersion: adapter.engineVersion,
          ok: false,
          error: `INVALID_ENGINE_OUTPUT: ${check.reason ?? 'unknown'}`,
        };
      }
      return {
        engineId: adapter.engineId,
        engineVersion: adapter.engineVersion,
        ok: true,
        output: output as EngineOutputContract,
      };
    } catch (e) {
      return {
        engineId: adapter.engineId,
        engineVersion: adapter.engineVersion,
        ok: false,
        error: e instanceof Error ? e.message : 'UNKNOWN_ENGINE_ERROR',
      };
    }
  }
}
