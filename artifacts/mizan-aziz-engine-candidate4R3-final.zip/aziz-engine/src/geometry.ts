import type { Point, Polygon, BoundingBox } from './types.js';

const EPS = 1e-9;
const finitePoint = (p: Point): boolean =>
  Number.isFinite(p.x) && Number.isFinite(p.y);
const cross = (o: Point, a: Point, b: Point): number =>
  (a.x - o.x) * (b.y - o.y) - (a.y - o.y) * (b.x - o.x);

export function signedArea(pts: Point[]): number {
  if (pts.length < 3 || pts.some((p) => !finitePoint(p))) return 0;
  let s = 0;
  for (let i = 0; i < pts.length; i++) {
    const a = pts[i]!, b = pts[(i + 1) % pts.length]!;
    s += a.x * b.y - b.x * a.y;
  }
  return s / 2;
}

export function pointOnSegment(p: Point, a: Point, b: Point, eps = EPS): boolean {
  if (![p, a, b].every(finitePoint)) return false;
  const len = Math.hypot(b.x - a.x, b.y - a.y);
  if (len < EPS) return Math.abs(p.x - a.x) <= eps && Math.abs(p.y - a.y) <= eps;
  if (Math.abs(cross(a, b, p)) > eps * Math.max(1, len)) return false;
  return (
    p.x >= Math.min(a.x, b.x) - eps &&
    p.x <= Math.max(a.x, b.x) + eps &&
    p.y >= Math.min(a.y, b.y) - eps &&
    p.y <= Math.max(a.y, b.y) + eps
  );
}

function properIntersection(p1: Point, p2: Point, p3: Point, p4: Point): boolean {
  const d1 = cross(p1, p2, p3);
  const d2 = cross(p1, p2, p4);
  const d3 = cross(p3, p4, p1);
  const d4 = cross(p3, p4, p2);
  return (
    ((d1 > EPS && d2 < -EPS) || (d1 < -EPS && d2 > EPS)) &&
    ((d3 > EPS && d4 < -EPS) || (d3 < -EPS && d4 > EPS))
  );
}

export function segmentsIntersect(
  p1: Point, p2: Point, p3: Point, p4: Point,
): boolean {
  if (properIntersection(p1, p2, p3, p4)) return true;
  return (
    pointOnSegment(p3, p1, p2) ||
    pointOnSegment(p4, p1, p2) ||
    pointOnSegment(p1, p3, p4) ||
    pointOnSegment(p2, p3, p4)
  );
}

function ringLocation(p: Point, ring: Point[]): -1 | 0 | 1 {
  if (ring.length < 3) return -1;
  for (let i = 0; i < ring.length; i++) {
    if (pointOnSegment(p, ring[i]!, ring[(i + 1) % ring.length]!)) return 0;
  }
  let inside = false;
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
    const a = ring[i]!, b = ring[j]!;
    if (
      (a.y > p.y) !== (b.y > p.y) &&
      p.x < ((b.x - a.x) * (p.y - a.y)) / (b.y - a.y + EPS) + a.x
    ) {
      inside = !inside;
    }
  }
  return inside ? 1 : -1;
}

function polygonLocation(p: Point, poly: Polygon): -1 | 0 | 1 {
  const outer = ringLocation(p, poly.points);
  if (outer < 0) return -1;
  if (outer === 0) return 0;
  for (const h of poly.holes ?? []) {
    const loc = ringLocation(p, h);
    if (loc === 1) return -1;
    if (loc === 0) return 0;
  }
  return 1;
}

function ringSelfIntersects(r: Point[]): boolean {
  for (let i = 0; i < r.length; i++) {
    for (let j = i + 1; j < r.length; j++) {
      if (j === i + 1 || (i === 0 && j === r.length - 1)) continue;
      if (segmentsIntersect(r[i]!, r[(i + 1) % r.length]!, r[j]!, r[(j + 1) % r.length]!)) {
        return true;
      }
    }
  }
  return false;
}

export function isValidPolygon(p: Polygon | undefined | null): p is Polygon {
  if (!p || !Array.isArray(p.points) || p.points.length < 3) return false;
  if (p.points.some((q) => !finitePoint(q))) return false;
  if (Math.abs(signedArea(p.points)) <= EPS) return false;
  if (ringSelfIntersects(p.points)) return false;
  for (const h of p.holes ?? []) {
    if (h.length < 3 || h.some((q) => !finitePoint(q))) return false;
    if (Math.abs(signedArea(h)) <= EPS) return false;
    if (ringSelfIntersects(h)) return false;
    for (const q of h) if (ringLocation(q, p.points) === -1) return false;
  }
  return true;
}

export function polygonArea(p: Polygon): number {
  if (!isValidPolygon(p)) return 0;
  let a = Math.abs(signedArea(p.points));
  for (const h of p.holes ?? []) a -= Math.abs(signedArea(h));
  return Math.max(0, a);
}

export function bboxOf(p: Polygon): BoundingBox {
  if (!p.points.length || p.points.some((q) => !finitePoint(q))) {
    return { x: NaN, y: NaN, w: NaN, h: NaN };
  }
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (const q of p.points) {
    if (q.x < minX) minX = q.x;
    if (q.y < minY) minY = q.y;
    if (q.x > maxX) maxX = q.x;
    if (q.y > maxY) maxY = q.y;
  }
  return { x: minX, y: minY, w: maxX - minX, h: maxY - minY };
}

export function bboxOverlap(a: BoundingBox, b: BoundingBox, eps = 1e-6): boolean {
  if (![a.x, a.y, a.w, a.h, b.x, b.y, b.w, b.h].every(Number.isFinite)) return false;
  return !(
    a.x + a.w <= b.x + eps ||
    b.x + b.w <= a.x + eps ||
    a.y + a.h <= b.y + eps ||
    b.y + b.h <= a.y + eps
  );
}

const ringsOf = (p: Polygon): Point[][] => [p.points, ...(p.holes ?? [])];

function boundariesProperlyCross(a: Polygon, b: Polygon): boolean {
  for (const ra of ringsOf(a)) {
    for (const rb of ringsOf(b)) {
      for (let i = 0; i < ra.length; i++) {
        for (let j = 0; j < rb.length; j++) {
          if (properIntersection(ra[i]!, ra[(i + 1) % ra.length]!, rb[j]!, rb[(j + 1) % rb.length]!)) return true;
        }
      }
    }
  }
  return false;
}

export function polygonsOverlap(a: Polygon, b: Polygon): boolean {
  if (!isValidPolygon(a) || !isValidPolygon(b)) return false;
  if (!bboxOverlap(bboxOf(a), bboxOf(b))) return false;
  if (boundariesProperlyCross(a, b)) return true;
  if (a.points.some((q) => polygonLocation(q, b) === 1)) return true;
  if (b.points.some((q) => polygonLocation(q, a) === 1)) return true;
  const allAOnB = a.points.every((q) => polygonLocation(q, b) === 0);
  const allBOnA = b.points.every((q) => polygonLocation(q, a) === 0);
  return allAOnB && allBOnA && polygonArea(a) > EPS && polygonArea(b) > EPS;
}

export function polygonContains(outer: Polygon, inner: Polygon): boolean {
  if (!isValidPolygon(outer) || !isValidPolygon(inner)) return false;
  if (boundariesProperlyCross(outer, inner)) return false;
  for (const q of inner.points) if (polygonLocation(q, outer) < 0) return false;
  for (let i = 0; i < inner.points.length; i++) {
    const a = inner.points[i]!;
    const b = inner.points[(i + 1) % inner.points.length]!;
    const m = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
    if (polygonLocation(m, outer) < 0) return false;
  }
  for (const h of outer.holes ?? []) {
    if (h.some((q) => polygonLocation(q, inner) === 1)) return false;
  }
  return true;
}

export function pointInPolygon(p: Point, poly: Polygon): boolean {
  return isValidPolygon(poly) && polygonLocation(p, poly) >= 0;
}

export function centroidOf(poly: Polygon): Point {
  if (!isValidPolygon(poly)) return { x: NaN, y: NaN };
  const ringCentroid = (ring: Point[]) => {
    let a2 = 0, cx = 0, cy = 0;
    for (let i = 0; i < ring.length; i++) {
      const p = ring[i]!;
      const q = ring[(i + 1) % ring.length]!;
      const k = p.x * q.y - q.x * p.y;
      a2 += k;
      cx += (p.x + q.x) * k;
      cy += (p.y + q.y) * k;
    }
    return { area: Math.abs(a2 / 2), x: cx / (3 * a2), y: cy / (3 * a2) };
  };
  const o = ringCentroid(poly.points);
  let mass = o.area;
  let sx = o.x * o.area;
  let sy = o.y * o.area;
  for (const h of poly.holes ?? []) {
    const c = ringCentroid(h);
    mass -= c.area;
    sx -= c.x * c.area;
    sy -= c.y * c.area;
  }
  return mass > EPS ? { x: sx / mass, y: sy / mass } : { x: NaN, y: NaN };
}
