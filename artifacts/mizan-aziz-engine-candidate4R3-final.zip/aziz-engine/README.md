# @mizan/aziz-engine

محرك القرار الهندسي الذي يحكم بين مخرجات عدة محركات تصميم، ويختار الأفضل وفق قيود صريحة ومقاييس متعددة المحاور، مع تفسير قابل للتتبع.

## Status

CANDIDATE #4R3 — HARDENED — TYPECHECK/BUILD PASS — 65/65 EXACT REGRESSION CASES PASS — OFFICIAL VITEST BINARY UNAVAILABLE IN THIS ENVIRONMENT

لم يُشغَّل typecheck / test / build في بيئة نظيفة بعد. أي ادعاء بالاكتمال قبل تشغيل فعلي غير مقبول.

## ما يفعله AZIZ

- يستقبل مخرجات محركات متعددة (EngineAdapter) عبر عقد موحد.
- يفحص كل مرشح مقابل قيود المستخدم الصريحة (hard constraints).
- يكشف التعارضات بين المحركات.
- يقيس كل مرشح على 15 محور جودة منفصل.
- يستبعد المرشحات المخالفة أو منخفضة الثقة.
- يختار فائزًا واحدًا مع مسار قرار قابل للتفسير (DecisionTrace).
- يرفض الاختيار إذا فشل الجميع، ويُنتج RefinementRequest بدل اختراع نتيجة.

## ما لا يفعله AZIZ

- لا يولّد هندسة. يقيّم هندسة أنتجتها محركات أخرى.
- لا يعتمد على @mizan/design-core.
- لا يعتمد على @mizan/engineering-core.
- لا يعدّل مخرجاته بشكل صامت. كل قرار يُسجَّل في Provenance.

## Independence

AZIZ لا يستورد design-core ولا engineering-core. يتصل بالمحركات فقط عبر EngineAdapter. التكامل يتم خارج هذه الحزمة.

## البنية

```
aziz-engine/
├── package.json
├── tsconfig.json
├── vitest.config.ts
├── README.md
├── src/
│   ├── index.ts
│   ├── types.ts
│   ├── util.ts
│   ├── geometry.ts
│   ├── registry.ts
│   ├── output-validation.ts
│   ├── hard-constraints.ts
│   ├── conflict-engine.ts
│   ├── scoring-engine.ts
│   ├── consensus-engine.ts
│   ├── refinement-engine.ts
│   ├── decision-trace.ts
│   ├── fake-engines.ts
│   └── aziz.ts
└── tests/
    └── regression.test.ts
```

## السياسات الصريحة

### stableStringify — صارم

يرفض صراحة أي إدخال غير متوافق مع JSON: undefined, function, symbol, bigint, NaN, +-Infinity, cycles, Date, Map, Set, RegExp, exotic objects. عند الرفض يرمي NonJsonInputError. لا sentinel strings. لا تحويل صامت.

### fnv1aHash — بصمة، ليست حماية

- الاستخدام: بصمة حتمية للمدخل، للاختبارات، للتتبع، وللتحقق من تطابق inputHash بين المحرك وAZIZ.
- ليس: cryptographic hash.
- ليس: دليل سلامة بيانات.
- للاستخدام الأمني مستقبلاً: SHA-256 أو BLAKE3.

### deterministicId — ترميز، ليس hash

- الترميز: length-prefixed per part.
- الهدف: منع تصادم delimiter.
- ليس: hash. ليس آمناً. فقط ترميز حتمي.

### Runtime Trust Boundary

- كل مخرجات المحركات تمر عبر validateEngineOutput قبل استخدامها.
- فشل التحقق يُسجَّل في Provenance ولا يوقف AZIZ.
- المرشح غير الصالح يُرفض بـ INVALID_SCHEMA أو VERSION_MISMATCH.

### Low-Confidence + Critical Conflict

- مرشح تحت confidenceFloor يُرفض، ولا يُختار بسبب متوسط score مرتفع.
- مرشح مرتبط بـ critical conflict يُرفض بـ UNRESOLVED_ENGINE_CONFLICT.

### Determinism

عند نفس المدخلات ونفس مخرجات المحركات ونفس الإعدادات: نفس الفائز، نفس الترتيب، نفس معرّفات Provenance، نفس مسار القرار. الـAI خارج AZIZ. AZIZ حتمي.

## محاور القياس (15)

requirementCoverage, hardConstraintCompliance, geometryValidity, areaAccuracy, adjacency, circulation, privacy, guestFamilySeparation, serviceFlow, accessibility, daylightPotential, ventilationPotential, designEfficiency, referenceCompatibility, unresolvedPenalty.

## RejectionReasonCode

OUTSIDE_BUILDING_BOUNDARY, ROOM_OVERLAP, HARD_REQUIREMENT_MISSING, INVALID_ACCESS, PRIVACY_CONFLICT, AREA_TOLERANCE_EXCEEDED, UNRESOLVED_ENGINE_CONFLICT, EMPTY_CANDIDATE, INVALID_SCHEMA, VERSION_MISMATCH, TIMEOUT, LOW_CONFIDENCE, DUPLICATE_CANDIDATE.

## التشغيل

```bash
pnpm install
pnpm --filter @mizan/aziz-engine typecheck
pnpm --filter @mizan/aziz-engine test
pnpm --filter @mizan/aziz-engine build
```

## حدود معروفة

- ventilationPotential نسخة من daylightPotential في v1.
- circulationScore و referenceCompatibility heuristics.
- custom hard constraints غير مدعومة.
- لا merge بين مرشحين.
- Reference Engine غير مطبّق.
- Integration مع design-core و engineering-core لم يُبنَ.
- Property/fuzz testing لم يُضَف.
- M/L findings من تقرير التدقيق لم تُعالج في هذه الدفعة.

## قواعد المساهمة

- لا تعديل على main.
- لا تعديل على فروع المطورين الآخرين.
- كل دفعة ترفع إلى فرعها المخصص.
- فتح PR إلى integration/multi-engine فقط.
- لا merge قبل تشغيل فعلي موثّق.

## Candidate #4R3 hardening summary

This derivative keeps the original package boundary and adds runtime hardening only inside AZIZ:

- Full top-level `AzizInput` shape validation before dereferencing untrusted input.
- Per-element validation for assumptions, warnings, and constraint evaluations.
- Structural validation for engine capabilities and execution/provenance metadata.
- Candidate invocation and room-count consistency checks.
- Global candidate-ID collision rejection.
- Canonical design deduplication independent of the engine-supplied `geometryHash` and input ordering.
- Low-confidence rejection before duplicate arbitration.
- Output-level critical warnings and constraint-evaluation conflicts now cover every candidate in the affected output.

Independent execution after the last code change:

- TypeScript typecheck: PASS.
- Build: PASS.
- Exact regression source cases: 65/65 PASS using a local Node test compatibility harness because the Vitest package cannot be installed in this network-restricted environment.
- Deterministic malformed-input fuzz: 40,000 cases total, 0 uncaught throws (10,000 arbitrary `process()` inputs + 20,000 arbitrary `validateEngineOutput()` inputs + 10,000 valid-shell inputs with arbitrary engine output elements).
- Relative import resolution: 44/44 resolved.

The official `vitest run` command remains environment-blocked here because the Vitest package is not locally installed and the npm registry is unreachable. The previously supplied Candidate #4R execution log showed 43/43 under Vitest 2.1.9; the additional R1/R2/R3 cases were executed independently through the exact test source with the compatibility harness.

