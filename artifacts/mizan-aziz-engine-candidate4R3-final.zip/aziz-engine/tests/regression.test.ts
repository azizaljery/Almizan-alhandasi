import { describe, it, expect } from 'vitest';
import {
  createAziz, createFakeEngine, fixedClock, AdapterRegistry,
  NonJsonInputError, stableStringify, deterministicId, fnv1aHash,
  polygonContains, polygonsOverlap, centroidOf, pointInPolygon,
  defaultConfig, normalizeConfig, resolveWeights,
} from '../src/index.js';

const clock = fixedClock('2026-01-01T00:00:00.000Z', 0);
const ctx = { plotArea: 500, cityCode: 'riyadh', locale: 'ar-SA' };
const baseInput = { requestId: 'r', hardConstraints: [], softPreferences: [], context: ctx };
const rect = (x: number, y: number, w: number, h: number) => ({
  points: [{ x, y }, { x: x + w, y }, { x: x + w, y: y + h }, { x, y: y + h }],
});

describe('B1 — centroidOf', () => {
  it('returns finite for rect', () => {
    const c = centroidOf(rect(0, 0, 2, 2));
    expect(Number.isFinite(c.x)).toBe(true);
    expect(c.x).toBeCloseTo(1);
  });
  it('area-weighted for L-shape', () => {
    const l = { points: [
      { x: 0, y: 0 }, { x: 10, y: 0 }, { x: 10, y: 4 },
      { x: 4, y: 4 }, { x: 4, y: 10 }, { x: 0, y: 10 },
    ]};
    const c = centroidOf(l);
    expect(Number.isFinite(c.x)).toBe(true);
    expect(c.x).toBeLessThan(5);
  });
  it('NaN for invalid polygon', () => {
    expect(Number.isNaN(centroidOf({ points: [] }).x)).toBe(true);
  });
});

describe('B2 — no require()', () => {
  it('scoring module imports without runtime error', async () => {
    const mod = await import('../src/scoring-engine.js');
    expect(typeof mod.scoreCandidate).toBe('function');
  });
});

describe('C1 — boundary semantics', () => {
  const outer = rect(0, 0, 10, 10);
  it('contains rooms touching each edge', () => {
    expect(polygonContains(outer, rect(0, 2, 2, 2))).toBe(true);
    expect(polygonContains(outer, rect(8, 2, 2, 2))).toBe(true);
    expect(polygonContains(outer, rect(2, 8, 2, 2))).toBe(true);
    expect(polygonContains(outer, rect(2, 0, 2, 2))).toBe(true);
  });
  it('touching rooms do not overlap', () => {
    expect(polygonsOverlap(rect(0, 0, 2, 2), rect(2, 0, 2, 2))).toBe(false);
  });
  it('point on edge is inside', () => {
    expect(pointInPolygon({ x: 0, y: 5 }, outer)).toBe(true);
    expect(pointInPolygon({ x: 10, y: 5 }, outer)).toBe(true);
  });
});

describe('C2 — holes', () => {
  it('rejects bridge across hole', () => {
    const donut = { points: rect(0, 0, 10, 10).points, holes: [rect(3, 3, 4, 4).points] };
    expect(polygonContains(donut, rect(2, 4, 6, 2))).toBe(false);
  });
  it('overlap on hole area returns false', () => {
    const donut = { points: rect(0, 0, 10, 10).points, holes: [rect(3, 3, 4, 4).points] };
    expect(polygonsOverlap(donut, rect(4, 4, 1, 1))).toBe(false);
  });
});

describe('C3 — runtime trust boundary', () => {
  it('malformed output does not throw', async () => {
    const e = createFakeEngine({ engineId: 'e1', role: 'geometry', fail: 'malformed' }, clock);
    const out = await e.execute(baseInput).catch(() => null);
    const aziz = createAziz({}, clock);
    const state = await aziz.process({ ...baseInput, engineOutputs: [out as never] });
    expect(['no-candidates', 'all-rejected']).toContain(state.status);
  });
  it('non-JSON input throws NonJsonInputError', () => {
    expect(() => stableStringify({ a: undefined })).toThrow(NonJsonInputError);
    expect(() => stableStringify({ a: NaN })).toThrow(NonJsonInputError);
    const cyclic: Record<string, unknown> = {};
    cyclic.self = cyclic;
    expect(() => stableStringify(cyclic)).toThrow(NonJsonInputError);
  });
});

describe('C4 — low-confidence & critical conflicts rejected', () => {
  it('low-confidence candidate cannot win', async () => {
    const good = createFakeEngine({ engineId: 'e-good', role: 'geometry', confidence: 0.9 }, clock);
    const bad = createFakeEngine({ engineId: 'e-bad', role: 'custom', confidence: 0.05 }, clock);
    const oGood = await good.execute(baseInput);
    const oBad = await bad.execute(baseInput);
    const state = await createAziz({ confidenceFloor: 0.3 }, clock).process({
      ...baseInput, engineOutputs: [oGood, oBad],
    });
    expect(state.selectedCandidateId).toBe(oGood.candidates[0]!.candidateId);
    expect(state.candidatesRejected.some((r) => r.code === 'LOW_CONFIDENCE')).toBe(true);
  });
  it('candidate with critical conflict cannot win', async () => {
    const a = createFakeEngine({ engineId: 'e-a', role: 'geometry', confidence: 0.9 }, clock);
    const b = createFakeEngine({ engineId: 'e-b', role: 'custom', confidence: 0.9 }, clock);
    const oA = await a.execute(baseInput);
    const oB = await b.execute(baseInput);
    oA.warnings.push({ id: 'w1', code: 'CRIT', message: 'critical', severity: 'critical' });
    const state = await createAziz({}, clock).process({ ...baseInput, engineOutputs: [oA, oB] });
    expect(state.candidatesRejected.some((r) => r.code === 'UNRESOLVED_ENGINE_CONFLICT')).toBe(true);
  });
});

describe('H1/H2 — config normalization', () => {
  it('deep clones default config', () => {
    const c1 = defaultConfig();
    const c2 = defaultConfig();
    c1.weights.privacy = 999;
    expect(c2.weights.privacy).not.toBe(999);
  });
  it('rejects invalid confidenceFloor', () => {
    expect(() => normalizeConfig({ confidenceFloor: 2 })).toThrow();
  });
  it('rejects unknown activeProfile', () => {
    expect(() => normalizeConfig({ activeProfile: 'nonexistent' })).toThrow();
  });
  it('rejects non-integer maxRefinementAttempts', () => {
    expect(() => normalizeConfig({ maxRefinementAttempts: 1.5 })).toThrow();
  });
  it('resolveWeights does not mutate config', () => {
    const c = defaultConfig();
    const before = JSON.stringify(c.weights);
    resolveWeights(c, ctx);
    expect(JSON.stringify(c.weights)).toBe(before);
  });
});

describe('H3 — transitive tie ordering', () => {
  it('selection invariant to input order', async () => {
    const e1 = createFakeEngine({ engineId: 'e1', role: 'geometry', placementSeed: 1 }, clock);
    const e2 = createFakeEngine({ engineId: 'e2', role: 'architectural', placementSeed: 2 }, clock);
    const e3 = createFakeEngine({ engineId: 'e3', role: 'reference', placementSeed: 3 }, clock);
    const outputs = await Promise.all([e1, e2, e3].map((e) => e.execute(baseInput)));
    const s1 = await createAziz({}, clock).process({ ...baseInput, engineOutputs: outputs });
    const s2 = await createAziz({}, clock).process({ ...baseInput, engineOutputs: [...outputs].reverse() });
    expect(s1.selectedCandidateId).toBe(s2.selectedCandidateId);
  });
});

describe('H4 — candidatesReceived', () => {
  it('counts only structurally valid candidates', async () => {
    const e = createFakeEngine({ engineId: 'e1', role: 'geometry' }, clock);
    const out = await e.execute(baseInput);
    const state = await createAziz({}, clock).process({ ...baseInput, engineOutputs: [out] });
    expect(state.candidatesReceived).toBe(out.candidates.length);
  });
});

describe('H5 — refinement bounded', () => {
  it('null when attempts exceeded', async () => {
    const e = createFakeEngine({ engineId: 'e1', role: 'geometry', fail: 'version-mismatch' }, clock);
    const out = await e.execute(baseInput);
    const aziz = createAziz({ maxRefinementAttempts: 1 }, clock);
    const state = await aziz.process({
      ...baseInput,
      engineOutputs: [out],
      previousRefinement: {
        requestId: 'prev', createdAt: '2026-01-01T00:00:00.000Z', attempt: 1, reason: 'prev',
        failedConstraints: [], failedCandidates: [], engineHints: [],
        mustPreserve: { hardConstraintIds: [], explicitAreas: [], requiredRooms: [] },
        mayChange: [], mayNotChange: [], deadlineMs: 30000,
      },
    });
    expect(state.refinementRequest).toBeNull();
  });
});

describe('H6 — deterministic fake IDs', () => {
  it('same input → same candidate IDs', async () => {
    const e = createFakeEngine({ engineId: 'e1', role: 'geometry', placementSeed: 5 }, clock);
    const o1 = await e.execute(baseInput);
    const o2 = await e.execute(baseInput);
    expect(o1.candidates[0]!.candidateId).toBe(o2.candidates[0]!.candidateId);
    expect(o1.invocationId).toBe(o2.invocationId);
  });
});

describe('H7 — empty candidate rejected', () => {
  it('empty output → no-candidates', async () => {
    const e = createFakeEngine({ engineId: 'e1', role: 'geometry', fail: 'empty' }, clock);
    const out = await e.execute(baseInput);
    const state = await createAziz({}, clock).process({ ...baseInput, engineOutputs: [out] });
    expect(state.status).toBe('no-candidates');
  });
});

describe('H8 — cross-engine conflicts only', () => {
  it('same engine, multiple candidates → no placement conflict', async () => {
    const e = createFakeEngine({ engineId: 'e1', role: 'geometry', candidateCount: 3, placementSeed: 1 }, clock);
    const out = await e.execute(baseInput);
    const state = await createAziz({}, clock).process({ ...baseInput, engineOutputs: [out] });
    const placementConflicts = state.conflicts.filter((c) => c.subject.startsWith('room-type:'));
    expect(placementConflicts.length).toBe(0);
  });
});

describe('H9/H10/H11 — hard constraint fixes', () => {
  it('explicit_area: roomId priority', async () => {
    const e = createFakeEngine({ engineId: 'e1', role: 'geometry' }, clock);
    const out = await e.execute(baseInput);
    const state = await createAziz({}, clock).process({
      ...baseInput, engineOutputs: [out],
      hardConstraints: [{
        id: 'hc-1', kind: 'explicit_area', description: 'majlis exact',
        value: { roomId: 'r-majlis', area: 36 }, source: 'user', priority: 'must',
      }],
    });
    expect(state.candidatesRejected.some((r) => r.code === 'AREA_TOLERANCE_EXCEEDED')).toBe(false);
  });
  it('privacy_required: missing room → failure', async () => {
    const e = createFakeEngine({ engineId: 'e1', role: 'geometry' }, clock);
    const hardConstraints = [{
      id: 'hc-priv', kind: 'privacy_required' as const, description: 'majlis far',
      value: { fromType: 'majlis', toType: 'does-not-exist', minDistance: 5 },
      source: 'user' as const, priority: 'must' as const,
    }];
    const engineInput = { ...baseInput, hardConstraints };
    const out = await e.execute(engineInput);
    const state = await createAziz({}, clock).process({ ...engineInput, engineOutputs: [out] });
    expect(state.candidatesRejected.some((r) => r.code === 'PRIVACY_CONFLICT')).toBe(true);
  });
  it('access_required: missing link → failure', async () => {
    const e = createFakeEngine({ engineId: 'e1', role: 'geometry' }, clock);
    const hardConstraints = [{
      id: 'hc-access', kind: 'access_required' as const, description: 'ghost link',
      value: { roomId: 'r-bedroom-1', fromRoomId: 'ghost-room' },
      source: 'user' as const, priority: 'must' as const,
    }];
    const engineInput = { ...baseInput, hardConstraints };
    const out = await e.execute(engineInput);
    const state = await createAziz({}, clock).process({ ...engineInput, engineOutputs: [out] });
    expect(state.candidatesRejected.some((r) => r.code === 'INVALID_ACCESS')).toBe(true);
  });
});

describe('stableStringify — strict policy', () => {
  it('throws on undefined', () => { expect(() => stableStringify({ a: undefined })).toThrow(NonJsonInputError); });
  it('throws on function', () => { expect(() => stableStringify({ a: () => 1 })).toThrow(NonJsonInputError); });
  it('throws on symbol', () => { expect(() => stableStringify({ a: Symbol('x') })).toThrow(NonJsonInputError); });
  it('throws on bigint', () => { expect(() => stableStringify({ a: 1n })).toThrow(NonJsonInputError); });
  it('throws on NaN', () => { expect(() => stableStringify({ a: NaN })).toThrow(NonJsonInputError); });
  it('throws on Infinity', () => { expect(() => stableStringify({ a: Infinity })).toThrow(NonJsonInputError); });
  it('throws on cycle', () => { const o: Record<string, unknown> = {}; o.self = o; expect(() => stableStringify(o)).toThrow(NonJsonInputError); });
  it('throws on Date', () => { expect(() => stableStringify({ d: new Date() })).toThrow(NonJsonInputError); });
  it('accepts valid JSON', () => { expect(stableStringify({ a: 1, b: 'x' })).toBe('{"a":1,"b":"x"}'); });
});

describe('deterministicId — delimiter safety', () => {
  it('no collision between ["a|b","c"] and ["a","b|c"]', () => {
    expect(deterministicId('p', ['a|b', 'c'])).not.toBe(deterministicId('p', ['a', 'b|c']));
  });
});

describe('fnv1aHash — deterministic fingerprint', () => {
  it('is deterministic', () => { expect(fnv1aHash('abc')).toBe(fnv1aHash('abc')); });
  it('matches expected format', () => { expect(fnv1aHash('x')).toMatch(/^[0-9a-f]{8}$/); });
});

describe('AdapterRegistry — timeout cleanup', () => {
  it('clears timer on success', async () => {
    const r = new AdapterRegistry();
    r.register(createFakeEngine({ engineId: 'e1', role: 'geometry' }, clock));
    const results = await r.invokeAll(baseInput, 5000);
    expect(results[0]!.ok).toBe(true);
  });
  it('returns ENGINE_TIMEOUT on timeout', async () => {
    const r = new AdapterRegistry();
    r.register(createFakeEngine({ engineId: 'e1', role: 'geometry', fail: 'timeout' }, clock));
    const results = await r.invokeAll(baseInput, 100);
    expect(results[0]!.ok).toBe(false);
    expect(results[0]!.error).toBe('ENGINE_TIMEOUT');
  });
});


describe('Runtime contracts — resilience', () => {
  it('continues when one engine output is malformed', async () => {
    const good = createFakeEngine({ engineId: 'good', role: 'geometry', placementSeed: 1 }, clock);
    const bad = createFakeEngine({ engineId: 'bad', role: 'custom', fail: 'malformed' }, clock);
    const [goodOutput, badOutput] = await Promise.all([good.execute(baseInput), bad.execute(baseInput)]);
    const state = await createAziz({}, clock).process({ ...baseInput, engineOutputs: [badOutput, goodOutput] });
    expect(state.status).toBe('selected');
    expect(state.selectedCandidateId).toBe(goodOutput.candidates[0]!.candidateId);
    expect(state.provenance.some((p) => p.subject === 'output-validation')).toBe(true);
  });

  it('rejects non-finite geometry instead of selecting it', async () => {
    const engine = createFakeEngine({ engineId: 'nan', role: 'geometry' }, clock);
    const output = await engine.execute(baseInput);
    output.candidates[0]!.footprint.points[0]!.x = Number.NaN;
    const state = await createAziz({}, clock).process({ ...baseInput, engineOutputs: [output] });
    expect(state.selectedCandidateId).toBeNull();
    expect(state.status).toBe('no-candidates');
    expect(state.provenance.some((p) => p.subject === 'candidate-validation')).toBe(true);
  });
});


describe('Runtime contracts — nested output validation', () => {
  it('rejects malformed warning entries without crashing and continues', async () => {
    const good = createFakeEngine({ engineId: 'good-warning', role: 'geometry', placementSeed: 1 }, clock);
    const bad = createFakeEngine({ engineId: 'bad-warning', role: 'custom', placementSeed: 2 }, clock);
    const [goodOutput, badOutput] = await Promise.all([good.execute(baseInput), bad.execute(baseInput)]);
    badOutput.warnings = [null as never];
    const state = await createAziz({}, clock).process({ ...baseInput, engineOutputs: [badOutput, goodOutput] });
    expect(state.status).toBe('selected');
    expect(state.selectedCandidateId).toBe(goodOutput.candidates[0]!.candidateId);
    expect(state.provenance.some((p) => p.statement.includes('WARNING_INVALID'))).toBe(true);
  });

  it('rejects malformed constraint evaluations without crashing and continues', async () => {
    const good = createFakeEngine({ engineId: 'good-constraint', role: 'geometry', placementSeed: 1 }, clock);
    const bad = createFakeEngine({ engineId: 'bad-constraint', role: 'custom', placementSeed: 2 }, clock);
    const [goodOutput, badOutput] = await Promise.all([good.execute(baseInput), bad.execute(baseInput)]);
    badOutput.constraintsEvaluated = [null as never];
    const state = await createAziz({}, clock).process({ ...baseInput, engineOutputs: [badOutput, goodOutput] });
    expect(state.status).toBe('selected');
    expect(state.selectedCandidateId).toBe(goodOutput.candidates[0]!.candidateId);
    expect(state.provenance.some((p) => p.statement.includes('CONSTRAINT_EVALUATION_INVALID'))).toBe(true);
  });

  it('failed engine outputs do not participate in cross-engine conflicts', async () => {
    const good = createFakeEngine({ engineId: 'good-failed-isolation', role: 'geometry', placementSeed: 1 }, clock);
    const failed = createFakeEngine({ engineId: 'failed-isolation', role: 'custom', placementSeed: 2 }, clock);
    const [goodOutput, failedOutput] = await Promise.all([good.execute(baseInput), failed.execute(baseInput)]);
    goodOutput.constraintsEvaluated = [{ constraintId: 'c1', satisfied: true, confidence: 1 }];
    failedOutput.constraintsEvaluated = [{ constraintId: 'c1', satisfied: false, confidence: 1 }];
    failedOutput.execution.status = 'failed';
    failedOutput.execution.errorMessage = 'boom';
    const state = await createAziz({}, clock).process({ ...baseInput, engineOutputs: [goodOutput, failedOutput] });
    expect(state.status).toBe('selected');
    expect(state.conflicts.some((c) => c.subject === 'constraint-eval:c1')).toBe(false);
  });
});


describe('Runtime contracts — AZIZ input collection validation', () => {
  it('rejects malformed assumption entries without crashing and continues', async () => {
    const good = createFakeEngine({ engineId: 'good-assumption', role: 'geometry', placementSeed: 1 }, clock);
    const bad = createFakeEngine({ engineId: 'bad-assumption', role: 'custom', placementSeed: 2 }, clock);
    const [goodOutput, badOutput] = await Promise.all([good.execute(baseInput), bad.execute(baseInput)]);
    badOutput.assumptions = [null as never];
    const state = await createAziz({}, clock).process({ ...baseInput, engineOutputs: [badOutput, goodOutput] });
    expect(state.status).toBe('selected');
    expect(state.selectedCandidateId).toBe(goodOutput.candidates[0]!.candidateId);
    expect(state.provenance.some((p) => p.statement.includes('ASSUMPTION_INVALID'))).toBe(true);
  });

  it('rejects non-array engineOutputs without throwing', async () => {
    const state = await createAziz({}, clock).process({
      ...baseInput,
      engineOutputs: null as never,
    });
    expect(state.status).toBe('no-candidates');
    expect(state.provenance.some((p) => p.statement.includes('ENGINE_OUTPUTS_NOT_ARRAY'))).toBe(true);
  });

  it('rejects malformed hardConstraints without throwing', async () => {
    const state = await createAziz({}, clock).process({
      ...baseInput,
      hardConstraints: [null] as never,
      engineOutputs: [],
    });
    expect(state.status).toBe('no-candidates');
    expect(state.provenance.some((p) => p.statement.includes('HARD_CONSTRAINT_INVALID'))).toBe(true);
  });

  it('rejects malformed softPreferences without throwing or corrupting scoring', async () => {
    const state = await createAziz({}, clock).process({
      ...baseInput,
      softPreferences: [null] as never,
      engineOutputs: [],
    });
    expect(state.status).toBe('no-candidates');
    expect(state.provenance.some((p) => p.statement.includes('SOFT_PREFERENCE_INVALID'))).toBe(true);
  });
});

describe('Runtime contracts — complete AZIZ input boundary', () => {
  it('rejects null top-level input without throwing', async () => {
    const state = await createAziz({}, clock).process(null as never);
    expect(state.status).toBe('no-candidates');
    expect(state.provenance.some((p) => p.statement.includes('INPUT_NOT_OBJECT'))).toBe(true);
  });

  it('rejects undefined top-level input without throwing', async () => {
    const state = await createAziz({}, clock).process(undefined as never);
    expect(state.status).toBe('no-candidates');
    expect(state.provenance.some((p) => p.statement.includes('INPUT_NOT_OBJECT'))).toBe(true);
  });

  it('rejects missing requestId without throwing', async () => {
    const state = await createAziz({}, clock).process({} as never);
    expect(state.status).toBe('no-candidates');
    expect(state.provenance.some((p) => p.statement.includes('REQUEST_ID_INVALID'))).toBe(true);
  });

  it('rejects invalid context without throwing', async () => {
    const state = await createAziz({}, clock).process({
      ...baseInput,
      context: null,
      engineOutputs: [],
    } as never);
    expect(state.status).toBe('no-candidates');
    expect(state.provenance.some((p) => p.statement.includes('CONTEXT_INVALID'))).toBe(true);
  });

  it('rejects non-finite plot area before scoring', async () => {
    const state = await createAziz({}, clock).process({
      ...baseInput,
      context: { plotArea: Number.NaN, cityCode: 'riyadh', locale: 'ar-SA' },
      engineOutputs: [],
    } as never);
    expect(state.status).toBe('no-candidates');
    expect(state.provenance.some((p) => p.statement.includes('PLOT_AREA_INVALID'))).toBe(true);
  });
});

describe('Runtime contracts — complete engine-output boundary', () => {
  it('rejects malformed capabilities and continues with valid engine', async () => {
    const good = createFakeEngine({ engineId: 'good-cap', role: 'geometry', placementSeed: 1 }, clock);
    const bad = createFakeEngine({ engineId: 'bad-cap', role: 'custom', placementSeed: 2 }, clock);
    const [goodOutput, badOutput] = await Promise.all([good.execute(baseInput), bad.execute(baseInput)]);
    badOutput.capabilities = null as never;
    const state = await createAziz({}, clock).process({ ...baseInput, engineOutputs: [badOutput, goodOutput] });
    expect(state.status).toBe('selected');
    expect(state.selectedCandidateId).toBe(goodOutput.candidates[0]!.candidateId);
    expect(state.provenance.some((p) => p.statement.includes('CAPABILITIES_INVALID'))).toBe(true);
  });

  it('rejects execution version mismatch and continues', async () => {
    const good = createFakeEngine({ engineId: 'good-exec-version', role: 'geometry', placementSeed: 1 }, clock);
    const bad = createFakeEngine({ engineId: 'bad-exec-version', role: 'custom', placementSeed: 2 }, clock);
    const [goodOutput, badOutput] = await Promise.all([good.execute(baseInput), bad.execute(baseInput)]);
    badOutput.execution.version = '999.0.0';
    const state = await createAziz({}, clock).process({ ...baseInput, engineOutputs: [badOutput, goodOutput] });
    expect(state.status).toBe('selected');
    expect(state.provenance.some((p) => p.statement.includes('EXECUTION_VERSION_MISMATCH'))).toBe(true);
  });

  it('rejects invalid provenance timestamps and continues', async () => {
    const good = createFakeEngine({ engineId: 'good-prov-time', role: 'geometry', placementSeed: 1 }, clock);
    const bad = createFakeEngine({ engineId: 'bad-prov-time', role: 'custom', placementSeed: 2 }, clock);
    const [goodOutput, badOutput] = await Promise.all([good.execute(baseInput), bad.execute(baseInput)]);
    badOutput.provenance.requestedAt = '';
    const state = await createAziz({}, clock).process({ ...baseInput, engineOutputs: [badOutput, goodOutput] });
    expect(state.status).toBe('selected');
    expect(state.provenance.some((p) => p.statement.includes('PROVENANCE_TIMESTAMPS_INVALID'))).toBe(true);
  });

  it('rejects candidate invocation mismatch without poisoning valid candidate', async () => {
    const good = createFakeEngine({ engineId: 'good-inv', role: 'geometry', placementSeed: 1 }, clock);
    const bad = createFakeEngine({ engineId: 'bad-inv', role: 'custom', placementSeed: 2 }, clock);
    const [goodOutput, badOutput] = await Promise.all([good.execute(baseInput), bad.execute(baseInput)]);
    badOutput.candidates[0]!.invocationId = 'different-invocation';
    const state = await createAziz({}, clock).process({ ...baseInput, engineOutputs: [badOutput, goodOutput] });
    expect(state.status).toBe('selected');
    expect(state.selectedCandidateId).toBe(goodOutput.candidates[0]!.candidateId);
    expect(state.provenance.some((p) => p.subject === 'candidate-validation')).toBe(true);
  });

  it('rejects inconsistent roomCount metadata', async () => {
    const good = createFakeEngine({ engineId: 'good-room-count', role: 'geometry', placementSeed: 1 }, clock);
    const bad = createFakeEngine({ engineId: 'bad-room-count', role: 'custom', placementSeed: 2 }, clock);
    const [goodOutput, badOutput] = await Promise.all([good.execute(baseInput), bad.execute(baseInput)]);
    badOutput.candidates[0]!.metrics.roomCount += 1;
    const state = await createAziz({}, clock).process({ ...baseInput, engineOutputs: [badOutput, goodOutput] });
    expect(state.status).toBe('selected');
    expect(state.selectedCandidateId).toBe(goodOutput.candidates[0]!.candidateId);
    expect(state.provenance.some((p) => p.subject === 'candidate-validation')).toBe(true);
  });
});

describe('Runtime contracts — duplicate arbitration invariants', () => {
  it('rejects all candidates that collide on a global candidateId', async () => {
    const a = createFakeEngine({ engineId: 'dup-id-a', role: 'geometry', placementSeed: 0 }, clock);
    const b = createFakeEngine({ engineId: 'dup-id-b', role: 'custom', placementSeed: 1 }, clock);
    const [oa, ob] = await Promise.all([a.execute(baseInput), b.execute(baseInput)]);
    ob.candidates[0]!.candidateId = oa.candidates[0]!.candidateId;
    const state = await createAziz({}, clock).process({ ...baseInput, engineOutputs: [oa, ob] });
    expect(state.selectedCandidateId).toBeNull();
    expect(state.status).toBe('all-rejected');
    expect(state.candidatesRejected.filter((r) => r.code === 'DUPLICATE_CANDIDATE').length).toBe(2);
  });

  it('deduplicates canonical design content independently of reported geometryHash and input order', async () => {
    const a = createFakeEngine({ engineId: 'dup-design-a', role: 'geometry', placementSeed: 0, confidence: 0.7 }, clock);
    const b = createFakeEngine({ engineId: 'dup-design-b', role: 'custom', placementSeed: 0, confidence: 0.9 }, clock);
    const [oa, ob] = await Promise.all([a.execute(baseInput), b.execute(baseInput)]);
    ob.candidates[0]!.geometryHash = 'forged-different-hash';
    const expected = ob.candidates[0]!.candidateId;
    const forward = await createAziz({}, clock).process({ ...baseInput, engineOutputs: [oa, ob] });
    const reverse = await createAziz({}, clock).process({ ...baseInput, engineOutputs: [ob, oa] });
    expect(forward.selectedCandidateId).toBe(expected);
    expect(reverse.selectedCandidateId).toBe(expected);
    expect(forward.candidatesRejected.some((r) => r.code === 'DUPLICATE_CANDIDATE')).toBe(true);
  });

  it('filters low-confidence candidates before duplicate design arbitration', async () => {
    const low = createFakeEngine({ engineId: 'dup-low', role: 'custom', placementSeed: 0, confidence: 0.05 }, clock);
    const high = createFakeEngine({ engineId: 'dup-high', role: 'geometry', placementSeed: 0, confidence: 0.9 }, clock);
    const [olow, ohigh] = await Promise.all([low.execute(baseInput), high.execute(baseInput)]);
    const state = await createAziz({ confidenceFloor: 0.3 }, clock).process({ ...baseInput, engineOutputs: [olow, ohigh] });
    expect(state.selectedCandidateId).toBe(ohigh.candidates[0]!.candidateId);
    expect(state.candidatesRejected.some((r) => r.code === 'LOW_CONFIDENCE' && r.candidateId === olow.candidates[0]!.candidateId)).toBe(true);
  });
});

describe('Runtime contracts — output-level conflicts cover every candidate', () => {
  it('critical output warning rejects every candidate from that engine', async () => {
    const engine = createFakeEngine({ engineId: 'global-warning', role: 'geometry', candidateCount: 2, placementSeed: 0 }, clock);
    const output = await engine.execute(baseInput);
    output.warnings.push({ id: 'global-critical', code: 'CRIT', message: 'global critical warning', severity: 'critical' });
    const state = await createAziz({}, clock).process({ ...baseInput, engineOutputs: [output] });
    expect(state.selectedCandidateId).toBeNull();
    expect(state.status).toBe('all-rejected');
    expect(state.candidatesRejected.filter((r) => r.code === 'UNRESOLVED_ENGINE_CONFLICT').length).toBe(2);
  });

  it('constraint-evaluation conflict includes every candidate from participating outputs', async () => {
    const a = createFakeEngine({ engineId: 'constraint-multi-a', role: 'geometry', candidateCount: 2, placementSeed: 0 }, clock);
    const b = createFakeEngine({ engineId: 'constraint-multi-b', role: 'custom', candidateCount: 1, placementSeed: 1 }, clock);
    const [oa, ob] = await Promise.all([a.execute(baseInput), b.execute(baseInput)]);
    oa.constraintsEvaluated = [{ constraintId: 'shared-c', satisfied: true, confidence: 1 }];
    ob.constraintsEvaluated = [{ constraintId: 'shared-c', satisfied: false, confidence: 1 }];
    const state = await createAziz({}, clock).process({ ...baseInput, engineOutputs: [oa, ob] });
    const conflict = state.conflicts.find((c) => c.subject === 'constraint-eval:shared-c');
    expect(conflict?.participants.length).toBe(3);
    expect(conflict?.participants.some((p) => p.candidateId === oa.candidates[0]!.candidateId)).toBe(true);
    expect(conflict?.participants.some((p) => p.candidateId === oa.candidates[1]!.candidateId)).toBe(true);
    expect(conflict?.participants.some((p) => p.candidateId === ob.candidates[0]!.candidateId)).toBe(true);
  });
});
