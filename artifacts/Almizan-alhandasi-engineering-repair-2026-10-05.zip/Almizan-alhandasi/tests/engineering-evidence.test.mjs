import test from 'node:test';
import assert from 'node:assert/strict';
import { polygonsOverlap } from '../dist/integration/aziz/geometry.js';
import { evaluateHardConstraints } from '../dist/integration/aziz/hard-constraints.js';
import { defaultConfig } from '../dist/integration/aziz/index.js';
import { defaultRooms, normalizeRooms, validatePlot, generateModel, quantities, placeOpening, removeOpening, openingPoint } from '../dist/planner.mjs';
import { assessPlan } from '../dist/plan-evidence.mjs';
import { calculateMizanScore } from '../dist/mizan-score.mjs';
import { evaluateHomeModel } from '../dist/home-design-engine.mjs';
import { designIntelligenceContext, comparePatternToPlan } from '../dist/candidate-intelligence.mjs';
import { runMultiEngineDesign } from '../dist/multi-engine.mjs';
import { analyzeGeminiEngineering } from '../dist/gemini-engineering-layer.mjs';
import { geometryHash, candidateId } from '../dist/integration/control/reference/identity.mjs';
import { reviewCandidate, verifyBoundReview } from '../dist/integration/gemini/packages/design-intelligence/adapters/mizan-review-v1.js';
import { decideReviewed } from '../dist/integration/pipeline.mjs';

const rect = (x, y, w, h) => ({ points: [{ x, y }, { x: x + w, y }, { x: x + w, y: y + h }, { x, y: y + h }] });
test('AZIZ detects aligned strips, containment and identical polygons but permits contact', () => {
  for (const [a, b, expected] of [
    [rect(0, 0, 4, 2), rect(2, 0, 4, 2), true],
    [rect(0, 0, 4, 2), rect(0, 1, 4, 2), true],
    [rect(0, 0, 4, 2), rect(0, 0, 2, 2), true],
    [rect(0, 0, 4, 2), rect(0, 0, 4, 2), true],
    [rect(0, 0, 4, 2), rect(4, 0, 4, 2), false],
    [rect(0, 0, 4, 2), rect(4, 2, 4, 2), false],
    [rect(0, 0, 4, 2), rect(5, 0, 4, 2), false]
  ]) {
    for (const shift of [0, 1000]) for (const reverse of [false, true]) {
      const move = p => ({ points: p.points.map(v => ({ x: v.x + shift, y: v.y - shift })) });
      const aa = move(a), bb = move(b); if (reverse) { aa.points.reverse(); bb.points.reverse(); }
      assert.equal(polygonsOverlap(aa, bb), expected);
      assert.equal(polygonsOverlap(bb, aa), expected);
    }
  }
});
test('AZIZ overlap respects holes and concave notches', () => {
  const donut = { ...rect(0, 0, 10, 10), holes: [rect(2, 2, 6, 6).points] };
  assert.equal(polygonsOverlap(donut, rect(3, 3, 2, 2)), false);
  assert.equal(polygonsOverlap(donut, rect(1, 3, 2, 2)), true);
  const l = { points: [{x:0,y:0},{x:6,y:0},{x:6,y:2},{x:2,y:2},{x:2,y:6},{x:0,y:6}] };
  assert.equal(polygonsOverlap(l, rect(3, 3, 2, 2)), false);
  assert.equal(polygonsOverlap(l, rect(1, 3, 2, 2)), true);
});
test('AZIZ hard gate rejects the aligned room overlap before selection', () => {
  const candidate = { candidateId:'clash', producedBy:'test', footprint:rect(0,0,10,10), rooms:[
    {roomId:'a', clearArea:8, boundary:rect(1,1,4,2)}, {roomId:'b', clearArea:8, boundary:rect(3,1,4,2)} ] };
  const result = evaluateHardConstraints(candidate, [], defaultConfig());
  assert.equal(result.axisScore, 0);
  assert.ok(result.violations.some(v => v.code === 'ROOM_OVERLAP'));
});
const plot = validatePlot({width:35,length:45,floors:1,entry:'s',streets:{s:true},coverage:.75});
const rooms = normalizeRooms(defaultRooms());
const model = generateModel(plot, rooms);
test('windows do not change privacy; disconnection removes movement/ privacy scores', () => {
  const before = assessPlan(model), noWindows = structuredClone(model);
  noWindows.openings = noWindows.openings.filter(o => o.type !== 'window');
  assert.equal(assessPlan(noWindows).privacy.score, before.privacy.score);
  assert.equal(assessPlan(noWindows).daylight.score, 0);
  const disconnected = structuredClone(model);
  const target = disconnected.rooms.find(r => r.type === 'bedroom');
  disconnected.openings = disconnected.openings.filter(o => o.type !== 'door' || o.roomId !== target.id);
  const e = assessPlan(disconnected);
  assert.equal(e.circulation.score, null); assert.equal(e.privacy.score, null);
  assert.ok(e.access.data.disconnectedRoomIds.includes(target.id));
});
test('scores exclude unavailable engineering, reference and ventilation axes', () => {
  const score = calculateMizanScore(model);
  for (const key of ['ventilation','economy','compliance','reference','structural','acoustic','future']) {
    const axis = score.axes.find(a => a.key === key); assert.equal(axis.score, null); assert.equal(axis.status,'NOT_EVALUATED');
  }
  assert.equal(score.confidence, null); assert.ok(score.coverage.evaluatedAxes < score.coverage.totalAxes);
  const evaluation = evaluateHomeModel({plot,rooms,model}).evaluation;
  for (const key of ['ventilation','constructability','futureExpansion','solarOrientation','acousticSeparation','costEfficiency']) assert.equal(evaluation.metrics[key],null);
});
test('a user requirement to separate guest/family routes uses actual shared corridors', () => {
  const result = evaluateHomeModel({plot,rooms,model,discovery:{avoids:['مرور الضيوف عبر خصوصية العائلة']}}).evaluation;
  assert.ok(result.blockers.some(b => b.type === 'forbidden_relationship'));
  assert.equal(result.metrics.functionalAdjacency,0);
});
test('correct Design Intelligence contract preserves duplicate rooms and actual door edges', () => {
  const context = designIntelligenceContext(model);
  assert.equal(context.plot.areaSqM, plot.width * plot.length);
  assert.equal(context.requirements.spaces.length, rooms.length);
  for (const door of model.openings.filter(o => o.type === 'door')) assert.ok(context.candidateSpatialGraph.edges.some(e => e.openingId === door.id));
  const comparison = comparePatternToPlan({patternId:'test',requiredAdjacencies:[['KITCHEN','DINING'],['GUEST_ENTRANCE','GUEST_RECEPTION']],forbiddenAdjacencies:[]}, model);
  assert.equal(comparison.checks[0].status,'FAIL'); // A corridor route is not a direct door.
  assert.equal(comparison.checks[1].status,'NOT_EVALUATED');
  assert.equal(comparison.score,null);
});
test('live Gemini view reports missing clashes and uses footprint area excluding courtyard', async () => {
  const out = await runMultiEngineDesign({plot,rooms});
  const u = out.models.find(m => m.shape === 'u'), view = analyzeGeminiEngineering(u);
  assert.equal(view.coordination.summaryMetrics.totalClashesCount,null);
  assert.equal(view.coverage.crossDisciplineClashes,'NOT_EVALUATED');
  assert.equal(view.math.footprintM2, quantities(u).footprint);
  assert.ok(view.math.footprintM2 < u.building.w * u.building.h);
  const selected = out.aziz.scores.find(s => s.candidateId === out.decision.selectedCandidateId);
  for (const key of ['referenceCompatibility','ventilationPotential']) {
    const axis = selected.axes.find(a => a.axis === key); assert.equal(axis.value,null); assert.equal(axis.weight,0);
  }
});
test('opening edits clear stale candidate/review binding and retain exact geometry on removal', async () => {
  const out = await runMultiEngineDesign({plot,rooms});
  const model = out.models.find(m => m.shape === 'u');
  const wall = model.walls.find(w => w.type === 'ext' && !model.openings.some(o => o.wallId === w.id) && Math.hypot(w.x2-w.x1,w.y2-w.y1)>2);
  const edited = placeOpening(model,{type:'window',point:{x:(wall.x1+wall.x2)/2,y:(wall.y1+wall.y2)/2}});
  assert.equal(edited.integration.requiresReview,true);assert.equal(edited.integration.geometryHash,null);assert.equal(edited.integration.reviewId,null);
  assert.ok(model.integration.reviewId);
  const created=edited.openings.find(o=>!model.openings.some(old=>old.id===o.id));
  const removed=removeOpening(edited,openingPoint(edited,created));
  assert.deepEqual(removed.openings,model.openings);
});
test('rebound disconnected geometry is blocked and old review is rejected', async () => {
  const out = await runMultiEngineDesign({plot,rooms});
  const request = out.request;
  // Generate a bound candidate directly so this test is independent of AZIZ presentation fields.
  const {generateCandidate} = await import('../dist/integration/pipeline.mjs');
  const {candidate:c} = await generateCandidate(request,'rect');
  const original = await reviewCandidate(c,request);
  const target = c.geometry.rooms.find(r => r.type === 'bedroom');
  c.geometry.openings = c.geometry.openings.filter(o => o.type !== 'door' || o.roomId !== target.id);
  c.geometryHash = await geometryHash(c); c.candidateId = await candidateId(c);
  await assert.rejects(verifyBoundReview(original,c,request), /REVIEW_BINDING_MISMATCH/);
  const review = await reviewCandidate(c,request);
  assert.notEqual(review.checks.find(x => x.id === 'access-connectivity').status,'PASS');
  await assert.rejects(decideReviewed(request,[{candidate:c,review}]), /NATIVE_VALIDATION_FAILED/);
});
