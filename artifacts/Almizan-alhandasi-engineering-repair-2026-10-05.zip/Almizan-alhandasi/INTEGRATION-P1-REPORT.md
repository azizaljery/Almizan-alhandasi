# MIZAN v33 — P1 integrated candidate

Source baseline: Sites v33 source export, commit `dbc41c0ec424e389f81f0f14f13d288682e6744d`.

## Integrated path

`UI -> Claude P1 corrected planner -> Gemini P1 bound preliminary review -> AZIZ Candidate4R3 decision -> selected model -> existing 2D/3D/BOQ/editor/project-save`

The previously rejected external Gemini adapter proposal is not included.

## Verified in this candidate

- Baseline before edits: 78/78 site tests, build exit 0.
- Final after integration: 86/86 site tests, build exit 0.
- Dedicated multi-engine tests: 8/8.
- RECT/L/U generated and reviewed for south/north/east/west entry directions.
- AZIZ returns `SELECTED_PRELIMINARY`; construction approval remains false.
- Current street/neighbor setback controls are passed to the corrected Claude generation path and affect geometry identity/placement.
- Built-area cap failure is explicit; requested room program is not shrunk.
- Project save/import preserves exact integrated RECT/L/U geometry rather than rebuilding legacy strategies.
- Existing add/remove opening editor path was exercised on an integrated U model and remained valid.
- Corrected Claude source is vendored and mirrored into `dist/claude`; protected engine core files remain the delivered P1 versions.
- Corrected Gemini P1 review and AZIZ compiled modules are isolated under `dist/integration/`.
- 97 JavaScript modules under `dist/integration` pass `node --check`; no missing relative imports were found.
- Public-source secret scan found no `sk-...` token-like provider keys.

## Important limits still open

- Browser visual/cross-device acceptance has not yet been executed on this candidate.
- AI brief preferences are carried into the request but the first AZIZ integration weights only proven geometry/area/constraint axes; privacy/MEP/reference soft axes remain NOT_EVALUATED rather than fabricated.
- Production Cloudflare Worker remains the manually deployed `gentle-sun-5ef5`; its byte-for-byte source provenance is not established here and is not modified by this candidate.
- This package is not yet a production deployment.

## Main authored integration changes

- `dist/multi-engine.mjs` — website adapter and request construction.
- `dist/integration/pipeline.mjs` — frozen handoff pipeline adapted to static site paths and existing setback controls.
- `dist/integration/...` — corrected Gemini review modules, contract/reference support, compiled AZIZ runtime.
- `dist/app.mjs` — generation now uses the multi-engine pipeline and selected AZIZ model.
- `dist/project.mjs` — exact integrated model persistence/backward compatible legacy recipe rebuild.
- `tests/multi-engine.test.mjs` — integrated flow/save/editor/cap/direction tests.
- `vendor/claude-planner` + `dist/claude/compat-layer.mjs` — frozen corrected Claude P1 handoff.

## Local repair verification — 5 October 2026

هذه نسخة عمل محلية قابلة للمراجعة؛ لم يحدث دمج أو دفع أو نشر.

- أصل المقارنة هو `d32121e`، مع 95/95 اختبار موقع ناجح في نسخة مستقلة من HEAD. بعد الإصلاح نجح البناء و105/105 اختبار موقع، ومنها عشرة اختبارات جديدة للتصادم والأدلة.
- إصلاح عزيز المحلي يرصد تداخل المستطيلات المحاذية الذي كانت اختبارات الرؤوس تفوّته، مع الحفاظ على السماح بتلامس الحدود. أُثبت الفرق قبل/بعد من الملف الأصلي، واختُبرت الثقوب والتقعر والاحتواء وعكس اتجاه المضلع ورفض الغرف المتداخلة.
- يستخدم Design Intelligence عقد السياق الفعلي (`plot.areaSqM/frontageM/depthM` وبرنامج الغرف ومعرّفات الفتحات)، مع مقارنة علاقات المرجع بالأبواب المباشرة. العلاقات التي لا يمكن ربطها بالبيانات تبقى `NOT_EVALUATED`؛ بيانات مصدر المكتبة غير محققة مستقلًا.
- الوصول من التحقق الهندسي الأصلي ومسارات الأبواب والممرات. الخصوصية مؤشر اشتراك مسارات الضيافة والعائلة، والنوافذ لا تدخل في حسابها. مسافة مفقودة لا تصبح صفرًا. التربة والإنشاء والأنظمة والتهوية والأداء الصوتي والمطابقة والمرجع المحقق تبقى غير مُقيّمة.
- درجات الواجهة جزئية، وتُعاد أوزان المحاور المتاحة فقط؛ لا توجد ثقة معايرة أو درجات افتراضية للمحاور الناقصة. التعديل اليدوي للفتحات يلغي معرّفات ربط المراجعة السابقة، وتُعاد قراءة الهندسة الحالية.
- اجتازت النسخة ثمانية مسارات تفاعلية في Chromium 151، باستخدام Three.js الحقيقي وSwiftShader WebGL: التوليد بالاتجاهات الأربع، البدائل RECT/L/U، الجولة، التحرير بعد التكبير، الكميات، الحفظ والاستيراد عبر العامل، رفض تعدد الأدوار مع إبقاء الرسم، ومقاس لوحي 820×1180. لا توجد أخطاء JavaScript في الصفحة. هذه محاكاة مقاس لوحي وليست تجربة جهاز iPad فعليًا.
- كشف التحقق البصري قوسًا مفقودًا في تنسيق الواجهة يعطل القواعد اللاحقة؛ صُحح، وأصبح فحص المتصفح يثبت نسبة تباين لا تقل عن 4.5:1 لنصوص بطاقات التقييم. أقل نسبة مقاسة 5.70:1. عناوين التقييم توضح أن المقارنة جزئية.
- اختبارات حزم التسليم من مجلداتها الصحيحة: engineering-math ‏18/18، engineering-core ‏12/31، design-intelligence ‏44/66. الاختبارات الـ41 المتبقية تتعذر كلها بـ`ENOENT` بسبب غياب ملفات `dist/integration/gemini/fixtures/{candidates,requests,negative}`. لم تُختلق ملفات بديلة لادعاء نجاح اختبارات التسليم الأصلية.
- لم تُحدد حزمة إصلاح عزيز الخارجية أو رابط مهمتها. الأدوات المتاحة لا تعرض مهمة أخرى قابلة للمراسلة؛ التنفيذ تم في مساحة العمل الحالية. الفرع المتاح لعزيز يحتوي تسليمًا نصيًا قديمًا، ولم تظهر ملفات الإصلاح المحددة في فروع التكامل ونقطة التحكم التي فُحصت.
- خدمة AI الخارجية لم تُختبر حيًا؛ لا توجد بيانات اعتماد مهيأة في هذه البيئة. لم يتغير Worker أو إعداد النشر.

الأدلة في `evidence/engineering-repair/`: سجلات الأصل والنسخة المصححة، الفرق قبل/بعد، اختبارات الحزم، تقرير المتصفح، الصور، ملفات المشروع وCSV، وأثر Playwright. أمر إعادة تحقق المتصفح في هذه البيئة:

```sh
MIZAN_PLAYWRIGHT_PATH=/opt/codex/cua_node/lib/node_modules/playwright-core/index.mjs node scripts/verify-engineering-browser.mjs
```

يحتاج الأمر Chromium ونسخة Three.js ‏0.160.0 محفوظة محليًا، أو تحديد مساراتها عبر `MIZAN_CHROMIUM_PATH` و`MIZAN_THREE_PATH`. التحقق العام غير مكتمل حتى تتاح ملفات P1 الأصلية وحزمة الإصلاح الخارجية؛ الدمج والنشر غير معتمدين.
