import http from 'node:http';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {resolve,extname} from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const {chromium} = await import(process.env.MIZAN_PLAYWRIGHT_PATH || 'playwright');
const evidenceDir=resolve('evidence/engineering-repair');
await mkdir(evidenceDir,{recursive:true});
const root=resolve('dist'), types={'.html':'text/html','.mjs':'text/javascript','.js':'text/javascript','.json':'application/json','.css':'text/css','.svg':'image/svg+xml'};
const server=http.createServer(async(req,res)=>{
  try {
    const pathname=decodeURIComponent(new URL(req.url,'http://localhost').pathname);
    const path=resolve(root, pathname==='/'?'index.html':'.'+pathname);
    if(!path.startsWith(root+'/')) throw Error('Invalid path');
    res.setHeader('Content-Type',types[extname(path)]||'application/octet-stream'); res.end(await readFile(path));
  } catch {res.statusCode=404;res.end('Not found');}
});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
const url=`http://127.0.0.1:${server.address().port}`;
const browser=await chromium.launch({executablePath:process.env.MIZAN_CHROMIUM_PATH||'/usr/bin/chromium',headless:true,
  args:['--no-sandbox','--enable-unsafe-swiftshader','--use-angle=swiftshader']});
const context=await browser.newContext({viewport:{width:1440,height:1000},acceptDownloads:true});
await context.tracing.start({screenshots:true,snapshots:true});
const three=await readFile(process.env.MIZAN_THREE_PATH || '/tmp/mizan-three-0.160.0.min.js');
await context.route('https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.min.js',route=>route.fulfill({contentType:'text/javascript',body:three}));
await context.route('https://fonts.googleapis.com/**',route=>route.fulfill({contentType:'text/css',body:''}));
const page=await context.newPage(), errors=[],steps=[];
page.on('pageerror',error=>errors.push(error.message));
page.on('dialog',dialog=>dialog.accept());
const step=async(name,fn)=>{await fn();steps.push({name,status:'PASS'});console.log('PASS:',name);};
const save=async(name)=>{
  const pending=page.waitForEvent('download'); await page.locator('#saveProject').click(); const download=await pending;
  const path=resolve(evidenceDir,name);await download.saveAs(path);return JSON.parse(await readFile(path,'utf8'));
};
const generate=async()=>{
  await page.locator('#gen').click();
  await page.waitForFunction(()=>!document.getElementById('gen').disabled);
  const error=await page.locator('#generationError').textContent();assert.equal(error,'');
  await page.locator('#plan svg').waitFor();assert.equal(await page.locator('[data-alternative]').count(),3);
};
let original,minimumAssessmentTextContrast;
try {
  await page.goto(url,{waitUntil:'networkidle'});
  await step('Discovery -> land inputs -> design generation',async()=>{
    await page.locator('#enter').click(); await page.locator('[data-go="rating"]').click();
    await page.locator('#wid').fill('35');await page.locator('#len').fill('45');
    await page.locator('[data-next="design"]').first().click(); await generate();
    assert.equal(await page.locator('#plan [data-room-id]').count(),12);
    assert.match(await page.locator('#engineeringCards').textContent(),/غير مُقيّم/);
    assert.match(await page.locator('#mizanScoreGrade').textContent(),/مقارنة جزئية/);
    assert.match(await page.locator('#geminiCoverage').textContent(),/غير مُقيّم/);
  });
  await step('RECT/L/U selections feed 2D and project data',async()=>{
    for(let i=0;i<3;i++){
      await page.locator(`[data-alternative="${i}"]`).click();
      const project=await save(`browser-alternative-${i}.json`);
      assert.equal(project.design.embedded.rooms.length,await page.locator('#plan [data-room-id]').count());
      assert.equal(project.design.embedded.shape,['rect','l','u'][i]);
      if(i===2) original=project;
    }
  });
  await step('Actual WebGL render, interior tour and keyboard movement',async()=>{
    await page.locator('#view canvas').waitFor();assert.equal(await page.locator('#threeError').isVisible(),false);
    assert.ok(await page.locator('#view canvas').evaluate(c=>c.width>0&&c.height>0));
    await page.locator('#view').scrollIntoViewIfNeeded();await page.screenshot({path:resolve(evidenceDir,'browser-3d-overview.png')});
    await page.locator('#startTour').click();await page.waitForFunction(()=>document.getElementById('tourState').textContent.includes('الجولة'));
    await page.locator('#view').scrollIntoViewIfNeeded();await page.screenshot({path:resolve(evidenceDir,'browser-3d.png')});
    await page.keyboard.press('ArrowUp');await page.keyboard.press('ArrowLeft');await page.keyboard.press('Escape');
    await page.locator('[data-view="top"]').click();
  });
  await step('Zoomed 2D editor add/remove window invalidates bound review',async()=>{
    const m=original.design.embedded;
    const candidates=m.walls.filter(w=>w.type==='ext'&&!m.openings.some(o=>o.wallId===w.id)&&Math.hypot(w.x2-w.x1,w.y2-w.y1)>2)
      .map(w=>({x:(w.x1+w.x2)/2,y:(w.y1+w.y2)/2}));
    await page.locator('#zoomIn').click();await page.locator('#togglePlanEditor').click();
    await page.locator('[data-plan-tool="window"]').click();
    await page.locator('#plan').scrollIntoViewIfNeeded();
    const point=await page.locator('#plan svg').evaluate((svg,points)=>points.find(p=>{
      const v=svg.createSVGPoint();v.x=p.x;v.y=-p.y;const c=v.matrixTransform(svg.getScreenCTM());
      return document.getElementById('plan').contains(document.elementFromPoint(c.x,c.y));
    }),candidates);
    assert.ok(point,'An unoccupied exterior wall is visible after zoom');
    const clickPoint=async()=>{
      await page.locator('#plan').scrollIntoViewIfNeeded();
      await page.waitForFunction(() => {
        const element = document.getElementById('plan'), rect = element.getBoundingClientRect();
        window.scrollTo({ top: window.scrollY + rect.top - 150, behavior: 'instant' });
        return element.getBoundingClientRect().top >= 100;
      });
      const client=await page.locator('#plan svg').evaluate((svg,p)=>{const v=svg.createSVGPoint();v.x=p.x;v.y=-p.y;const c=v.matrixTransform(svg.getScreenCTM());return {x:c.x,y:c.y};},point);
      const hit=await page.evaluate(p=>document.getElementById('plan').contains(document.elementFromPoint(p.x,p.y)),client);
      assert.ok(hit,`Editor point is visible: ${JSON.stringify(client)}`);
      await page.mouse.click(client.x,client.y);
    };
    await clickPoint();const edited=await save('browser-edited.json');
    assert.equal(edited.design.embedded.openings.length,m.openings.length+1);
    assert.equal(edited.design.embedded.integration.requiresReview,true);
    await page.locator('[data-plan-tool="erase"]').click();await clickPoint();
    const removed=await save('browser-removed.json');assert.equal(removed.design.embedded.openings.length,m.openings.length);
  });
  await step('BOQ exports actual selected geometry and project restores through worker',async()=>{
    await page.locator('[data-tab="boq"]').click();await page.locator('#mat tbody tr').first().waitFor();
    assert.match(await page.locator('#tot').textContent(),/لم تُدخل أسعارًا/);
    const pending=page.waitForEvent('download');await page.locator('#exportBOQ').click();const csv=await pending;await csv.saveAs(resolve(evidenceDir,'browser-boq.csv'));
    await page.locator('[data-tab="design"]').click();
    await page.locator('#projectFile').setInputFiles(resolve(evidenceDir,'browser-alternative-2.json'));
    await page.waitForFunction(()=>document.getElementById('projectStatus').textContent.includes('تم استيراد'));
    const restored=await save('browser-restored.json');assert.deepEqual(restored.design.embedded,original.design.embedded);
  });
  await step('Multi-floor rejection preserves the last valid plan',async()=>{
    await page.locator('#floors').selectOption('2');await page.locator('#gen').click();
    await page.waitForFunction(()=>!document.getElementById('gen').disabled);
    assert.match(await page.locator('#generationError').textContent(),/يرسم الدور الأرضي فقط/);
    assert.equal(await page.locator('#plan [data-room-id]').count(),12);
    await page.locator('#floors').selectOption('1');
  });
  await step('Browser pipeline regenerates for north/east/west entrances',async()=>{
    for(const entry of ['n','e','w']){
      await page.locator('[data-tab="rating"]').click();
      const button=page.locator(`#streets [data-side="${entry}"]`);
      if(await button.getAttribute('aria-pressed')!=='true')await button.click();
      await page.locator('#entry').selectOption(entry);await page.locator('[data-tab="design"]').click();await generate();
      const saved=await save(`browser-direction-${entry}.json`);assert.equal(saved.design.embedded.plot.entry,entry);
    }
  });
  await step('Tablet viewport renders controls, missing-axis labels and readable assessment cards',async()=>{
    await page.setViewportSize({width:820,height:1180});await page.locator('#plan').scrollIntoViewIfNeeded();
    assert.equal(await page.locator('#gen').isEnabled(),true);assert.match(await page.locator('#mizanScoreAxes').textContent(),/غير مُقيّم/);
    assert.equal(await page.getByRole('heading',{name:'Mizan Score — المقارنة الجزئية',exact:true}).count(),1);
    await page.screenshot({path:resolve(evidenceDir,'browser-tablet.png')});
    await page.setViewportSize({width:1440,height:1000});await page.locator('#engineeringCards').scrollIntoViewIfNeeded();
    const contrast=await page.locator('#engineeringCards .insight,#mizanScoreAxes .insight,#insightCards .insight').evaluateAll(cards=>{
      const luminance=color=>{
        const channels=color.match(/[\d.]+/g).slice(0,3).map(Number).map(v=>{v/=255;return v<=.04045?v/12.92:((v+.055)/1.055)**2.4;});
        return channels[0]*.2126+channels[1]*.7152+channels[2]*.0722;
      };
      return cards.flatMap(card=>{
        const style=getComputedStyle(card), background=luminance(style.backgroundColor);
        if(style.backgroundImage!=='none')throw Error('Contrast check requires a solid assessment surface');
        return [...card.querySelectorAll('span,b,p')].map(e=>{
          const foreground=luminance(getComputedStyle(e).color);
          return {label:e.textContent,ratio:(Math.max(foreground,background)+.05)/(Math.min(foreground,background)+.05)};
        });
      });
    });
    assert.ok(contrast.length>0);for(const text of contrast)assert.ok(text.ratio>=4.5,`${text.label}: contrast ${text.ratio}`);
    minimumAssessmentTextContrast=Math.min(...contrast.map(text=>text.ratio));
    console.log('Minimum assessment text contrast:',minimumAssessmentTextContrast.toFixed(2));
    await page.screenshot({path:resolve(evidenceDir,'browser-engineering.png')});
  });
  assert.deepEqual(errors,[]);
  await writeFile(resolve(evidenceDir,'browser-report.json'),JSON.stringify({status:'PASS',steps,pageErrors:errors,
    browser:await browser.version(),rendering:'Chromium headless with real Three.js and SwiftShader WebGL',
    threeSha256:createHash('sha256').update(three).digest('hex'),minimumAssessmentTextContrast,limitations:['Tablet viewport emulation, not a physical iPad.','Remote AI service not exercised; no configured credentials.','Original AZIZ repair bundle/task not identified.']},null,2));
} catch(error){
  await page.screenshot({path:resolve(evidenceDir,'browser-failure.png')});
  await writeFile(resolve(evidenceDir,'browser-report.json'),JSON.stringify({status:'FAIL',steps,pageErrors:errors,error:error.stack},null,2));throw error;
} finally {
  await context.tracing.stop({path:resolve(evidenceDir,'browser-trace.zip')});await browser.close();await new Promise(r=>server.close(r));
}
